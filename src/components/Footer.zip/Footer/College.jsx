import React from 'react'

const College = () => {
  return (
    <div id='about-clg'>
      <h3>Reach Us</h3>
      <p>Rajalakshmi Engineering College, <br/>An Autonomous institution
Affiliated to Anna University, Chennai <br />
Rajalakshmi Nagar,
Thandalam, <br />
Chennai - 602105.</p>
    </div>
  )
}

export default College
